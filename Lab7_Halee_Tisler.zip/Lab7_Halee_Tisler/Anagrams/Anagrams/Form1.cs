﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Anagrams
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Clear the list
            lstAnagrams.Items.Clear();
            
            //create stream readers for the text files
            StreamReader DictFile;
            DictFile = File.OpenText("C:\\Windows\\Temp\\F21\\dict.txt");
            string DictWord;

            StreamReader PalFile;

            string PalWord;

            //create arrays for the text files
            int[] dictArray = new int[26];
            int[] palArray = new int[26];

            //loop that continues until the end of the dict text file
            while (!DictFile.EndOfStream)
            {
                PalFile = File.OpenText("C:\\Windows\\Temp\\F21\\pal.txt");

                DictWord = DictFile.ReadLine();

                //call the Histogram using an array and string for the parameters
                Histo.Histogram.CreateHistogram(dictArray, DictWord);

                //loop that continues until the end of the pal text file 
                while (!PalFile.EndOfStream)
                {
                    PalWord = PalFile.ReadLine();

                    //call the Histogram
                    Histo.Histogram.CreateHistogram(palArray, PalWord);

                    int count = 0; //counter for the matches

                    //loop that continues for the length of the pal array
                    for (int x = 0; x < palArray.Length; x++)
                    {
                        //if the anagrams match, increase the count
                        if (dictArray[x] == palArray[x])
                        {
                            count++; //count increases for every match
                        }
                    }

                    //if you find all of the matches, list them in the list box
                    if (count == 26)
                    {
                        lstAnagrams.Items.Add(DictWord + " -> " + PalWord);
                    }
                }
                //Close the PalFile
                PalFile.Close();
            }

            //Close the DictFile
            DictFile.Close();
        }
    }
}
